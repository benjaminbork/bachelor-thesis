package com.benjaminbork.thesis;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class LambdaFunction implements RequestHandler<Map<String, Object>, Map<String, Object>> {
    private static boolean isColdStart = true;

    @Override
    public Map<String, Object> handleRequest(Map<String, Object> input, Context context) {
        long startTime = System.currentTimeMillis();
        int cpuCores = Runtime.getRuntime().availableProcessors();
        Map<String, Object> response = new HashMap<>();

        try {
            // 1. Prepare the matrix multiplication
            JSONObject body = new JSONObject((String) input.get("body"));
            JSONObject payload = body.getJSONObject("payload");
            JSONArray matrixA = payload.getJSONArray("matrixA");
            JSONArray matrixB = payload.getJSONArray("matrixB");

            int matrixARows = matrixA.length();
            int matrixACols = matrixA.getJSONArray(0).length();
            int matrixBRows = matrixB.length();
            int matrixBCols = matrixB.getJSONArray(0).length();

            if (matrixACols != matrixBRows) {
                throw new Exception(
                        "Matrix A columns must be equal to Matrix B rows for multiplication");
            }
            int[][] result = new int[matrixARows][matrixBCols];

            // 2. Execute the matrix multiplication
            for (int i = 0; i < matrixARows; i++) {
                for (int j = 0; j < matrixBCols; j++) {
                    for (int k = 0; k < matrixACols; k++) {
                        result[i][j] += matrixA.getJSONArray(i).getInt(k) * matrixB.getJSONArray(k).getInt(j);
                    }
                }
            }

            // 3. Collect all metrics
            boolean wasColdStart = isColdStart;
            LambdaFunction.isColdStart = false;
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;

            response.put("statusCode", 200);
            response.put("body", new JSONObject()
                    .put("message", "Matrix mulitplication executed successfully")
                    .put("cloudProvider", "AWS Lambda")
                    .put("allocatedMemory", 512)
                    .put("cpuCores", cpuCores)
                    .put("region", System.getenv("AWS_REGION"))
                    .put("runTime", "Java 17")
                    .put("functionName", "matrix-multiplication")
                    .put("isColdStart", wasColdStart)
                    .put("executionTime", executionTime));
        } catch (Exception e) {
            response.put("statusCode", 400);
            response.put("body", new JSONObject()
                    .put("message", "Matrix mulitplication failed")
                    .put("error", e.getMessage())
                    .toString());
        }
        return response;

    }
}
